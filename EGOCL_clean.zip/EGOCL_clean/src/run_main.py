from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.summarize_cv import summarize_cv
from src.utils import ensure_dir, load_csv, save_csv


MAIN_HYPERPARAMETERS = {
    "num_folds": 5,
    "epochs": 100,
    "lr": 5e-4,
    "weight_decay": 1e-5,
    "hidden_dim": 128,
    "num_layers": 2,
    "dropout": 0.2,
    "batch_size": 512,
    "seed": 42,
    "patience": 20,
    "svd_dim": 64,
    "svd_topk": 20,
    "contrastive_weight": 0.1,
    "temperature": 0.2,
    "bpr_weight": 0.1,
    "easy_negative_ratio": 0.5,
    "ontology_negative_ratio": 0.3,
    "svd_negative_ratio": 0.2,
    "focal_alpha": 0.85,
    "focal_gamma": 1.5,
    "soft_f1_weight": 0.1,
    "attr_cl_weight": 0.05,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the main leakage-safe EGOCL five-fold experiment.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", default="results/main_egocl")
    parser.add_argument("--device", default="cuda", help="cuda, cpu, or auto")
    parser.add_argument("--quick", action="store_true", help="Smoke test: run one fold for one epoch.")
    return parser.parse_args()


def write_compat_outputs(output_dir: Path) -> None:
    summary_path = output_dir / "cv_summary.csv"
    mean_std_path = output_dir / "cv_mean_std.csv"
    if not summary_path.exists() or not mean_std_path.exists():
        return
    save_csv(load_csv(summary_path), output_dir / "fold_results.csv")

    rows = {row["metric"]: row for row in load_csv(mean_std_path)}
    lines = ["# Metrics Summary", "", "| Metric | Mean | Std |", "|---|---:|---:|"]
    for metric in [
        "test_auc",
        "test_aupr",
        "test_selected_threshold_f1",
        "test_selected_threshold_precision",
        "test_selected_threshold_recall",
        "best_val_aupr",
        "val_selected_threshold",
    ]:
        if metric in rows:
            lines.append(f"| {metric} | {float(rows[metric]['mean']):.6f} | {float(rows[metric]['std']):.6f} |")
    (output_dir / "metrics_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    log_rows = []
    fields: list[str] = ["fold_id"]
    for fold_dir in sorted((p for p in output_dir.glob("fold_*") if p.is_dir()), key=lambda p: int(p.name.split("_")[-1])):
        log_path = fold_dir / "train_log.csv"
        if not log_path.exists():
            continue
        with log_path.open("r", encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                out = {"fold_id": int(fold_dir.name.split("_")[-1])}
                out.update(row)
                log_rows.append(out)
                for key in out:
                    if key not in fields:
                        fields.append(key)
    if log_rows:
        save_csv(log_rows, output_dir / "training_log.csv", fields)


def main() -> None:
    args = parse_args()
    output_dir = ensure_dir(args.output_dir)
    num_folds = 1 if args.quick else MAIN_HYPERPARAMETERS["num_folds"]
    epochs = 1 if args.quick else MAIN_HYPERPARAMETERS["epochs"]
    patience = 1 if args.quick else MAIN_HYPERPARAMETERS["patience"]

    for fold_id in range(num_folds):
        fold_dir = ensure_dir(output_dir / f"fold_{fold_id}")
        command = [
            sys.executable,
            str(ROOT / "src" / "train_egocl.py"),
            "--data_dir",
            args.data_dir,
            "--output_dir",
            str(fold_dir),
            "--fold_id",
            str(fold_id),
            "--num_folds",
            str(MAIN_HYPERPARAMETERS["num_folds"]),
            "--epochs",
            str(epochs),
            "--lr",
            str(MAIN_HYPERPARAMETERS["lr"]),
            "--weight_decay",
            str(MAIN_HYPERPARAMETERS["weight_decay"]),
            "--hidden_dim",
            str(MAIN_HYPERPARAMETERS["hidden_dim"]),
            "--num_layers",
            str(MAIN_HYPERPARAMETERS["num_layers"]),
            "--dropout",
            str(MAIN_HYPERPARAMETERS["dropout"]),
            "--batch_size",
            str(MAIN_HYPERPARAMETERS["batch_size"]),
            "--seed",
            str(MAIN_HYPERPARAMETERS["seed"]),
            "--patience",
            str(patience),
            "--device",
            args.device,
        ]
        print(f"[run_main] starting fold {fold_id}/{num_folds - 1}", flush=True)
        subprocess.run(command, cwd=ROOT, check=True)

    summarize_cv(output_dir)
    write_compat_outputs(output_dir)
    print(f"[run_main] completed folds: {num_folds}", flush=True)
    print(f"[run_main] summary written to: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
