from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data_utils import (
    build_exclusion_set,
    build_positive_pairs,
    load_graph_tensors,
    load_tsrna_attribute_tensors,
    sample_negatives,
    split_edges_kfold,
)
from src.losses import bpr_loss, classification_loss_with_options, soft_f1_loss
from src.metrics import evaluate_at_threshold, evaluate_binary_classification
from src.models.ego_clgnn import EgoCLGNN
from src.preprocess.build_svd_features import compute_svd_features, save_svd_outputs
from src.utils import ensure_dir, save_csv, set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train one fold of the main EGOCL model.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--fold_id", type=int, required=True)
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--device", default="cuda")
    return parser.parse_args()


def resolve_device(device_arg: str) -> torch.device:
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device_arg == "cuda" and not torch.cuda.is_available():
        print("[train_egocl] CUDA requested but unavailable; falling back to CPU", flush=True)
        return torch.device("cpu")
    return torch.device(device_arg)


def make_labeled_pairs(pos_pairs: torch.Tensor, neg_pairs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    pairs = torch.cat([pos_pairs.long(), neg_pairs.long()], dim=0)
    labels = torch.cat(
        [
            torch.ones(pos_pairs.shape[0], dtype=torch.float32),
            torch.zeros(neg_pairs.shape[0], dtype=torch.float32),
        ],
        dim=0,
    )
    return pairs, labels


def weak_pairs_tensor(graph_data: dict[str, torch.Tensor | int | list[str]]) -> torch.Tensor:
    return torch.stack([graph_data["weak_tsrna_ids"].long(), graph_data["weak_disease_ids"].long()], dim=1)


def build_train_graph_data(
    graph_data: dict[str, torch.Tensor | int | list[str]],
    train_idx: torch.Tensor,
    use_weak_edges_in_graph: bool,
    blocked_pairs: torch.Tensor | None = None,
) -> dict[str, torch.Tensor | int | list[str]]:
    train_graph_data = graph_data.copy()
    edge_tsrna = graph_data["pos_tsrna_ids"][train_idx].long()
    edge_disease = graph_data["pos_disease_ids"][train_idx].long()
    edge_features = graph_data["pos_edge_features"][train_idx].float()
    edge_source = ["train_positive"] * edge_tsrna.shape[0]

    if use_weak_edges_in_graph:
        weak_tsrna = graph_data["weak_tsrna_ids"].long()
        weak_disease = graph_data["weak_disease_ids"].long()
        weak_features = graph_data["weak_edge_features"].float()
        weak_count = int(weak_tsrna.shape[0])
        if blocked_pairs is not None and blocked_pairs.numel() > 0:
            blocked = {(int(t), int(d)) for t, d in blocked_pairs.long().tolist()}
            keep_mask = torch.tensor(
                [(int(t), int(d)) not in blocked for t, d in zip(weak_tsrna.tolist(), weak_disease.tolist())],
                dtype=torch.bool,
            )
            weak_tsrna = weak_tsrna[keep_mask]
            weak_disease = weak_disease[keep_mask]
            weak_features = weak_features[keep_mask]
        edge_tsrna = torch.cat([edge_tsrna, weak_tsrna], dim=0)
        edge_disease = torch.cat([edge_disease, weak_disease], dim=0)
        edge_features = torch.cat([edge_features, weak_features], dim=0)
        edge_source.extend(["weak_prediction"] * int(weak_tsrna.shape[0]))
        train_graph_data["weak_edge_candidates_count"] = weak_count
        train_graph_data["weak_edge_filtered_count"] = weak_count - int(weak_tsrna.shape[0])

    train_graph_data["edge_tsrna"] = edge_tsrna
    train_graph_data["edge_disease"] = edge_disease
    train_graph_data["edge_features"] = edge_features
    train_graph_data["edge_source"] = edge_source
    return train_graph_data


def move_graph_data_to_device(
    graph_data: dict[str, torch.Tensor | int | list[str]],
    device: torch.device,
) -> dict[str, torch.Tensor | int | list[str]]:
    return {key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in graph_data.items()}


def predict_logits(
    model: EgoCLGNN,
    pairs: torch.Tensor,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    batch_size: int,
    device: torch.device,
) -> torch.Tensor:
    model.eval()
    logits = []
    with torch.no_grad():
        for start in range(0, pairs.shape[0], batch_size):
            batch_pairs = pairs[start : start + batch_size].to(device)
            logits.append(model(batch_pairs[:, 0], batch_pairs[:, 1], graph_data).detach().cpu())
    return torch.cat(logits)


def evaluate_split(
    model: EgoCLGNN,
    pairs: torch.Tensor,
    labels: torch.Tensor,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    batch_size: int,
    device: torch.device,
    criterion: nn.Module | None = None,
) -> tuple[dict[str, float], np.ndarray, np.ndarray, float | None]:
    logits = predict_logits(model, pairs, graph_data, batch_size, device)
    scores = torch.sigmoid(logits).numpy()
    metrics = evaluate_binary_classification(labels.cpu().numpy(), scores, threshold_search="all")
    loss = float(criterion(logits, labels.cpu()).item()) if criterion is not None else None
    return metrics, scores, logits.numpy(), loss


def selected_threshold_metrics(labels: torch.Tensor, scores: np.ndarray, threshold: float) -> dict[str, float]:
    return evaluate_at_threshold(labels.cpu().numpy(), scores, threshold, "selected_threshold")


def pair_rows(pairs: torch.Tensor, split: str, label: int | None = None) -> list[dict[str, int | str]]:
    rows = []
    for tsrna_id, disease_id in pairs.tolist():
        row: dict[str, int | str] = {"tsrna_id": int(tsrna_id), "disease_id": int(disease_id), "split": split}
        if label is not None:
            row["label"] = label
        rows.append(row)
    return rows


def save_split_files(
    output_dir: Path,
    splits: dict[str, torch.Tensor],
    train_neg: torch.Tensor,
    val_neg: torch.Tensor,
    test_neg: torch.Tensor,
    train_graph_data_cpu: dict[str, torch.Tensor | int | list[str]],
) -> None:
    save_csv(pair_rows(splits["train_pairs"], "train", 1), output_dir / "train_pos_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(splits["val_pairs"], "valid", 1), output_dir / "val_pos_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(splits["test_pairs"], "test", 1), output_dir / "test_pos_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(train_neg, "train", 0), output_dir / "train_neg_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(val_neg, "valid", 0), output_dir / "val_neg_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(test_neg, "test", 0), output_dir / "test_neg_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])

    edge_sources = train_graph_data_cpu.get("edge_source", ["message_graph"] * train_graph_data_cpu["edge_tsrna"].shape[0])
    graph_rows = [
        {"tsrna_id": int(t), "disease_id": int(d), "source": source}
        for t, d, source in zip(
            train_graph_data_cpu["edge_tsrna"].tolist(),
            train_graph_data_cpu["edge_disease"].tolist(),
            edge_sources,
        )
    ]
    save_csv(graph_rows, output_dir / "message_graph_edges.csv", ["tsrna_id", "disease_id", "source"])


def save_predictions(output_dir: Path, split_data: list[tuple[str, torch.Tensor, torch.Tensor, np.ndarray, np.ndarray]]) -> None:
    rows = []
    for split_name, pairs, labels, scores, logits in split_data:
        for pair, label, score, logit in zip(pairs.tolist(), labels.tolist(), scores.tolist(), logits.tolist()):
            rows.append(
                {
                    "tsrna_id": int(pair[0]),
                    "disease_id": int(pair[1]),
                    "label": int(label),
                    "logit": float(logit),
                    "score": float(score),
                    "split": split_name,
                }
            )
    save_csv(rows, output_dir / "predictions.csv", ["tsrna_id", "disease_id", "label", "logit", "score", "split"])


def split_score_means(labels: torch.Tensor, scores: np.ndarray) -> tuple[float, float]:
    labels_np = labels.cpu().numpy().astype(int)
    pos_scores = scores[labels_np == 1]
    neg_scores = scores[labels_np == 0]
    return (float(pos_scores.mean()) if pos_scores.size else 0.0, float(neg_scores.mean()) if neg_scores.size else 0.0)


def save_negative_sampling_stats(output_dir: Path, stats_by_split: dict[str, dict[str, int]]) -> None:
    rows = []
    for split, stats in stats_by_split.items():
        row = {"split": split}
        row.update(stats)
        rows.append(row)
    save_csv(rows, output_dir / "negative_sampling_stats.csv", ["split", "num_easy_negative", "num_ontology_negative", "num_svd_negative", "fallback_count"])


def add_sampling_svd_features(graph_data: dict[str, torch.Tensor | int | list[str]], train_pairs: torch.Tensor, svd_dim: int) -> dict[str, torch.Tensor | int | list[str]]:
    graph_data = graph_data.copy()
    _, disease_features = compute_svd_features(int(graph_data["num_tsrna"]), int(graph_data["num_disease"]), train_pairs, svd_dim)
    graph_data["sampling_disease_svd_features"] = disease_features
    return graph_data


def add_fold_local_svd(
    output_dir: Path,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    train_graph_data: dict[str, torch.Tensor | int | list[str]],
    splits: dict[str, torch.Tensor],
    svd_dim: int,
    svd_topk: int,
    edge_feat_dim: int,
) -> dict[str, torch.Tensor | int | list[str]]:
    blocked = torch.cat([splits["val_pairs"], splits["test_pairs"], weak_pairs_tensor(graph_data)], dim=0)
    torch.save(splits["train_pairs"], output_dir / "train_pos_pairs.pt")
    svd_data = save_svd_outputs(
        output_dir=output_dir,
        num_tsrna=int(graph_data["num_tsrna"]),
        num_disease=int(graph_data["num_disease"]),
        train_pos_pairs=splits["train_pairs"],
        svd_dim=svd_dim,
        svd_topk=svd_topk,
        edge_feat_dim=edge_feat_dim,
        blocked_pairs=blocked,
    )
    train_graph_data = train_graph_data.copy()
    train_graph_data.update(svd_data)
    return train_graph_data


def attribute_meta_counts(graph_data: dict[str, torch.Tensor | int | list[str]]) -> dict[str, int]:
    meta = graph_data.get("tsrna_attr_meta", {})
    if not isinstance(meta, dict):
        return {"kmer_dim": 64, "num_tsrna_types": 1, "num_source_tRNAs": 1, "num_anticodons": 1, "num_amino_acid_families": 1, "num_species": 1}
    return {
        "kmer_dim": int(meta.get("kmer_dim", 64)),
        "num_tsrna_types": int(meta.get("num_tsrna_types", 1)),
        "num_source_tRNAs": int(meta.get("num_source_tRNAs", 1)),
        "num_anticodons": int(meta.get("num_anticodons", 1)),
        "num_amino_acid_families": int(meta.get("num_amino_acid_families", 1)),
        "num_species": int(meta.get("num_species", 1)),
    }


def train_one_epoch(
    model: EgoCLGNN,
    train_pairs: torch.Tensor,
    train_labels: torch.Tensor,
    train_pos_pairs: torch.Tensor,
    train_neg_pairs: torch.Tensor,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    args: argparse.Namespace,
) -> dict[str, float]:
    model.train()
    train_pairs = train_pairs.to(device)
    train_labels = train_labels.to(device)
    train_pos_pairs = train_pos_pairs.to(device)
    train_neg_pairs = train_neg_pairs.to(device)

    optimizer.zero_grad()
    logits, aux = model(train_pairs[:, 0], train_pairs[:, 1], graph_data, return_aux=True, temperature=0.2)
    cls = classification_loss_with_options(logits, train_labels, use_focal_loss=True, focal_alpha=0.85, focal_gamma=1.5)
    cl = aux["contrastive_loss"]
    attr_cl = aux["attribute_contrastive_loss"]
    pos_count = train_pos_pairs.shape[0]
    neg_count = train_neg_pairs.shape[0]
    bpr = bpr_loss(logits[:pos_count], logits[pos_count : pos_count + neg_count])
    soft_f1 = soft_f1_loss(logits, train_labels)
    loss = cls + 0.1 * cl + 0.05 * attr_cl + 0.1 * bpr + 0.1 * soft_f1
    loss.backward()
    optimizer.step()

    return {
        "train_loss": float(loss.item()),
        "train_cls": float(cls.item()),
        "train_contrastive": float(cl.item()),
        "train_attr_contrastive": float(attr_cl.item()),
        "train_bpr": float(bpr.item()),
        "train_soft_f1": float(soft_f1.item()),
    }


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = ensure_dir(args.output_dir)
    device = resolve_device(args.device)

    graph_data = load_graph_tensors(args.data_dir)
    graph_data.update(load_tsrna_attribute_tensors(args.data_dir))
    pos_pairs = build_positive_pairs(graph_data)
    exclusion_set = build_exclusion_set(graph_data)
    splits = split_edges_kfold(pos_pairs, seed=args.seed, fold_id=args.fold_id, num_folds=args.num_folds, val_ratio=0.1)
    fold_offset = (args.fold_id + 1) * 10_000
    sampling_graph_data = add_sampling_svd_features(graph_data, splits["train_pairs"], 64)

    train_neg, train_neg_stats = sample_negatives(
        splits["train_pairs"], int(graph_data["num_tsrna"]), int(graph_data["num_disease"]), splits["train_pairs"].shape[0], exclusion_set, sampling_graph_data,
        seed=args.seed + fold_offset + 101, mode="three_level", easy_negative_ratio=0.5, ontology_negative_ratio=0.3, svd_negative_ratio=0.2, return_stats=True,
    )
    val_neg, val_neg_stats = sample_negatives(
        splits["val_pairs"], int(graph_data["num_tsrna"]), int(graph_data["num_disease"]), splits["val_pairs"].shape[0], exclusion_set, sampling_graph_data,
        seed=args.seed + fold_offset + 202, mode="three_level", easy_negative_ratio=0.5, ontology_negative_ratio=0.3, svd_negative_ratio=0.2, return_stats=True,
    )
    test_neg, test_neg_stats = sample_negatives(
        splits["test_pairs"], int(graph_data["num_tsrna"]), int(graph_data["num_disease"]), splits["test_pairs"].shape[0], exclusion_set, sampling_graph_data,
        seed=args.seed + fold_offset + 303, mode="three_level", easy_negative_ratio=0.5, ontology_negative_ratio=0.3, svd_negative_ratio=0.2, return_stats=True,
    )
    save_negative_sampling_stats(output_dir, {"train": train_neg_stats, "valid": val_neg_stats, "test": test_neg_stats})

    train_pairs, train_labels = make_labeled_pairs(splits["train_pairs"], train_neg)
    val_pairs, val_labels = make_labeled_pairs(splits["val_pairs"], val_neg)
    test_pairs, test_labels = make_labeled_pairs(splits["test_pairs"], test_neg)

    edge_feat_dim = graph_data["pos_edge_features"].shape[1]
    held_out_pairs = torch.cat([splits["val_pairs"], splits["test_pairs"]], dim=0)
    train_graph_data_cpu = build_train_graph_data(graph_data, splits["train_idx"], True, blocked_pairs=held_out_pairs)
    train_graph_data_cpu = add_fold_local_svd(output_dir, graph_data, train_graph_data_cpu, splits, 64, 20, edge_feat_dim)
    save_split_files(output_dir, splits, train_neg, val_neg, test_neg, train_graph_data_cpu)
    train_graph_data = move_graph_data_to_device(train_graph_data_cpu, device)
    attr_counts = attribute_meta_counts(graph_data)

    model = EgoCLGNN(
        num_tsrna=int(graph_data["num_tsrna"]),
        num_disease=int(graph_data["num_disease"]),
        num_doid=int(graph_data["num_doid"]),
        hidden_dim=128,
        num_layers=2,
        edge_feat_dim=edge_feat_dim,
        svd_dim=64,
        dropout=0.2,
        use_evidence_gate=True,
        use_ontology=True,
        use_path_attention=True,
        use_direction=True,
        use_svd_features=True,
        decoder_type="hybrid",
        use_tsrna_attr=True,
        use_tsrna_seq=True,
        use_attr_contrastive=True,
        tsrna_attr_fusion="gated",
        attr_kmer_dim=attr_counts["kmer_dim"],
        attr_num_types=attr_counts["num_tsrna_types"],
        attr_num_sources=attr_counts["num_source_tRNAs"],
        attr_num_anticodons=attr_counts["num_anticodons"],
        attr_num_aminos=attr_counts["num_amino_acid_families"],
        attr_num_species=attr_counts["num_species"],
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = lambda logits, labels: classification_loss_with_options(logits, labels, use_focal_loss=True, focal_alpha=0.85, focal_gamma=1.5)
    best_val_aupr = -1.0
    best_epoch = 0
    best_val_threshold = 0.5
    best_val_threshold_method = "unknown"
    best_model_path = output_dir / "best_model.pt"
    train_log: list[dict[str, float | int | str]] = []
    stale_epochs = 0

    print(f"[train_egocl] fold {args.fold_id}/{args.num_folds - 1} device={device}", flush=True)
    print("[train_egocl] main configuration: weak-edge filtered EGOCL, train-only SVD, three-level negatives", flush=True)

    for epoch in range(1, args.epochs + 1):
        losses = train_one_epoch(model, train_pairs, train_labels, splits["train_pairs"], train_neg, train_graph_data, optimizer, device, args)
        val_metrics, val_scores, _, val_loss = evaluate_split(model, val_pairs, val_labels, train_graph_data, args.batch_size, device, criterion)
        val_pos_mean, val_neg_mean = split_score_means(val_labels, val_scores)
        improved = val_metrics["AUPR"] > best_val_aupr + 1e-12
        if improved:
            best_val_aupr = float(val_metrics["AUPR"])
            best_epoch = epoch
            best_val_threshold = float(val_metrics["best_threshold"])
            best_val_threshold_method = str(val_metrics["best_threshold_method"])
            stale_epochs = 0
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "epoch": epoch,
                    "val_aupr": best_val_aupr,
                    "val_best_threshold": best_val_threshold,
                    "val_best_threshold_method": best_val_threshold_method,
                },
                best_model_path,
            )
        else:
            stale_epochs += 1

        row = {
            "epoch": epoch,
            **losses,
            "val_loss": val_loss,
            "val_auc": val_metrics["AUC"],
            "val_aupr": val_metrics["AUPR"],
            "val_best_precision": val_metrics["best_precision"],
            "val_best_recall": val_metrics["best_recall"],
            "val_best_f1": val_metrics["best_f1"],
            "val_best_threshold": val_metrics["best_threshold"],
            "val_best_threshold_method": val_metrics["best_threshold_method"],
            "val_positive_score_mean": val_pos_mean,
            "val_negative_score_mean": val_neg_mean,
            "best_epoch": best_epoch,
        }
        train_log.append(row)
        print(
            f"[train_egocl] epoch {epoch:03d} loss={losses['train_loss']:.4f} val_auc={val_metrics['AUC']:.4f} val_aupr={val_metrics['AUPR']:.4f} val_f1={val_metrics['best_f1']:.4f}",
            flush=True,
        )
        if stale_epochs >= args.patience:
            print(f"[train_egocl] early stopping at epoch {epoch}; best epoch: {best_epoch}", flush=True)
            break

    checkpoint = torch.load(best_model_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    best_val_threshold = float(checkpoint["val_best_threshold"])
    best_val_threshold_method = str(checkpoint["val_best_threshold_method"])

    train_metrics, train_scores, train_logits, train_loss_eval = evaluate_split(model, train_pairs, train_labels, train_graph_data, args.batch_size, device, criterion)
    val_metrics, val_scores, val_logits, val_loss_eval = evaluate_split(model, val_pairs, val_labels, train_graph_data, args.batch_size, device, criterion)
    test_metrics, test_scores, test_logits, test_loss_eval = evaluate_split(model, test_pairs, test_labels, train_graph_data, args.batch_size, device, criterion)
    test_selected = selected_threshold_metrics(test_labels, test_scores, best_val_threshold)
    test_pos_mean, test_neg_mean = split_score_means(test_labels, test_scores)

    metrics_row = {
        "test_auc": test_metrics["AUC"],
        "test_aupr": test_metrics["AUPR"],
        "test_fixed_accuracy": test_metrics["fixed_accuracy"],
        "test_fixed_precision": test_metrics["fixed_precision"],
        "test_fixed_recall": test_metrics["fixed_recall"],
        "test_fixed_f1": test_metrics["fixed_f1"],
        "val_selected_threshold": best_val_threshold,
        "test_selected_threshold_accuracy": test_selected["selected_threshold_accuracy"],
        "test_selected_threshold_precision": test_selected["selected_threshold_precision"],
        "test_selected_threshold_recall": test_selected["selected_threshold_recall"],
        "test_selected_threshold_f1": test_selected["selected_threshold_f1"],
        "test_oracle_best_threshold": test_metrics["best_threshold"],
        "test_oracle_best_accuracy": test_metrics["best_accuracy"],
        "test_oracle_best_precision": test_metrics["best_precision"],
        "test_oracle_best_recall": test_metrics["best_recall"],
        "test_oracle_best_f1": test_metrics["best_f1"],
        "test_best_precision": test_metrics["best_precision"],
        "test_best_recall": test_metrics["best_recall"],
        "test_best_f1": test_metrics["best_f1"],
        "test_best_threshold": test_metrics["best_threshold"],
        "test_best_threshold_method": test_metrics["best_threshold_method"],
        "test_positive_score_mean": test_pos_mean,
        "test_negative_score_mean": test_neg_mean,
        "best_temperature": 1.0,
        "test_calibrated_auc": test_metrics["AUC"],
        "test_calibrated_aupr": test_metrics["AUPR"],
        "test_calibrated_selected_f1": test_selected["selected_threshold_f1"],
        "test_calibrated_precision": test_selected["selected_threshold_precision"],
        "test_calibrated_recall": test_selected["selected_threshold_recall"],
        "test_calibrated_threshold": best_val_threshold,
        "best_epoch": best_epoch,
        "best_val_aupr": best_val_aupr,
        "train_loss": train_loss_eval,
        "val_loss": val_loss_eval,
        "test_loss": test_loss_eval,
    }
    save_csv([metrics_row], output_dir / "metrics.csv")
    save_csv(train_log, output_dir / "train_log.csv", list(train_log[0].keys()))
    save_predictions(
        output_dir,
        [
            ("train", train_pairs, train_labels, train_scores, train_logits),
            ("valid", val_pairs, val_labels, val_scores, val_logits),
            ("test", test_pairs, test_labels, test_scores, test_logits),
        ],
    )

    config = vars(args).copy()
    config.update(
        {
            "model_name": "EGOCL",
            "main_result_hyperparameters_fixed_in_code": True,
            "use_evidence_gate": True,
            "use_ontology": True,
            "use_path_attention": True,
            "use_direction": True,
            "use_weak_edges_in_graph": True,
            "weak_edges_filtered_against_val_test_positives": True,
            "use_svd_features": True,
            "svd_dim": 64,
            "svd_topk": 20,
            "use_contrastive": True,
            "contrastive_weight": 0.1,
            "temperature": 0.2,
            "use_bpr": True,
            "bpr_weight": 0.1,
            "negative_sampling": "three_level",
            "easy_negative_ratio": 0.5,
            "ontology_negative_ratio": 0.3,
            "svd_negative_ratio": 0.2,
            "decoder_type": "hybrid",
            "threshold_search": "all",
            "use_focal_loss": True,
            "focal_alpha": 0.85,
            "focal_gamma": 1.5,
            "use_soft_f1_loss": True,
            "soft_f1_weight": 0.1,
            "use_tsrna_attr": True,
            "use_tsrna_seq": True,
            "tsrna_attr_fusion": "gated",
            "use_attr_contrastive": True,
            "attr_cl_weight": 0.05,
            "edge_feat_dim": int(edge_feat_dim),
            "best_epoch": int(best_epoch),
            "best_val_aupr": float(best_val_aupr),
            "best_val_threshold": float(best_val_threshold),
            "best_val_threshold_method": best_val_threshold_method,
            "train_positive_count": int(splits["train_pairs"].shape[0]),
            "val_positive_count": int(splits["val_pairs"].shape[0]),
            "test_positive_count": int(splits["test_pairs"].shape[0]),
        }
    )
    (output_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    print(f"[train_egocl] test AUC: {test_metrics['AUC']:.4f}", flush=True)
    print(f"[train_egocl] test AUPR: {test_metrics['AUPR']:.4f}", flush=True)
    print(f"[train_egocl] test selected-threshold F1: {test_selected['selected_threshold_f1']:.4f}", flush=True)
    print(f"[train_egocl] outputs written to: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
