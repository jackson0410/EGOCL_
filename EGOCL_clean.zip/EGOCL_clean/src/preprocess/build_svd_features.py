from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, save_csv


def compute_svd_features(
    num_tsrna: int,
    num_disease: int,
    train_pos_pairs: torch.Tensor,
    svd_dim: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    matrix = torch.zeros((num_tsrna, num_disease), dtype=torch.float32)
    if train_pos_pairs.numel() > 0:
        matrix[train_pos_pairs[:, 0].long(), train_pos_pairs[:, 1].long()] = 1.0

    max_rank = max(1, min(num_tsrna, num_disease, svd_dim))
    try:
        from sklearn.decomposition import TruncatedSVD

        svd = TruncatedSVD(n_components=max_rank, random_state=42)
        tsrna_features = torch.tensor(svd.fit_transform(matrix.numpy()), dtype=torch.float32)
        disease_features = torch.tensor(svd.components_.T, dtype=torch.float32)
        singular = torch.tensor(svd.singular_values_, dtype=torch.float32).clamp(min=1e-8)
        disease_features = disease_features * singular.sqrt().unsqueeze(0)
    except Exception:
        q = min(max_rank, min(matrix.shape) - 1) if min(matrix.shape) > 1 else 1
        u, s, v = torch.pca_lowrank(matrix, q=q, center=False)
        tsrna_features = u[:, :max_rank] * s[:max_rank].sqrt()
        disease_features = v[:, :max_rank] * s[:max_rank].sqrt()

    if max_rank < svd_dim:
        tsrna_pad = torch.zeros((num_tsrna, svd_dim - max_rank), dtype=torch.float32)
        disease_pad = torch.zeros((num_disease, svd_dim - max_rank), dtype=torch.float32)
        tsrna_features = torch.cat([tsrna_features, tsrna_pad], dim=1)
        disease_features = torch.cat([disease_features, disease_pad], dim=1)

    return tsrna_features[:, :svd_dim].contiguous(), disease_features[:, :svd_dim].contiguous()


def build_reconstructed_edges(
    tsrna_features: torch.Tensor,
    disease_features: torch.Tensor,
    train_pos_pairs: torch.Tensor,
    topk: int,
    edge_feat_dim: int,
    blocked_pairs: torch.Tensor | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, list[dict[str, object]]]:
    scores = tsrna_features @ disease_features.T
    if train_pos_pairs.numel() > 0:
        scores[train_pos_pairs[:, 0].long(), train_pos_pairs[:, 1].long()] = torch.finfo(scores.dtype).min
    if blocked_pairs is not None and blocked_pairs.numel() > 0:
        scores[blocked_pairs[:, 0].long(), blocked_pairs[:, 1].long()] = torch.finfo(scores.dtype).min

    topk = max(1, min(topk, disease_features.shape[0]))
    values, indices = torch.topk(scores, k=topk, dim=1)
    edge_tsrna = torch.arange(tsrna_features.shape[0], dtype=torch.long).repeat_interleave(topk)
    edge_disease = indices.reshape(-1).long()
    score_values = values.reshape(-1).float()
    finite_mask = torch.isfinite(score_values)
    edge_tsrna = edge_tsrna[finite_mask]
    edge_disease = edge_disease[finite_mask]
    score_values = score_values[finite_mask]

    if score_values.numel() > 0:
        min_score = score_values.min()
        max_score = score_values.max()
        norm_scores = (score_values - min_score) / (max_score - min_score + 1e-8)
    else:
        norm_scores = score_values

    edge_features = torch.zeros((edge_tsrna.shape[0], edge_feat_dim), dtype=torch.float32)
    if edge_features.numel() > 0:
        edge_features[:, 0] = norm_scores
        edge_features[:, 5] = norm_scores

    rows = [
        {
            "tsrna_id": int(t),
            "disease_id": int(d),
            "reconstructed_score": float(s),
        }
        for t, d, s in zip(edge_tsrna.tolist(), edge_disease.tolist(), norm_scores.tolist())
    ]
    return edge_tsrna, edge_disease, edge_features, rows


def save_svd_outputs(
    output_dir: str | Path,
    num_tsrna: int,
    num_disease: int,
    train_pos_pairs: torch.Tensor,
    svd_dim: int,
    svd_topk: int,
    edge_feat_dim: int,
    blocked_pairs: torch.Tensor | None = None,
) -> dict[str, torch.Tensor]:
    output_dir = ensure_dir(output_dir)
    tsrna_features, disease_features = compute_svd_features(num_tsrna, num_disease, train_pos_pairs, svd_dim)
    recon_t, recon_d, recon_features, recon_rows = build_reconstructed_edges(
        tsrna_features,
        disease_features,
        train_pos_pairs,
        svd_topk,
        edge_feat_dim,
        blocked_pairs,
    )

    torch.save(tsrna_features, Path(output_dir) / "tsrna_svd_features.pt")
    torch.save(disease_features, Path(output_dir) / "disease_svd_features.pt")
    torch.save(recon_t, Path(output_dir) / "svd_recon_tsrna_ids.pt")
    torch.save(recon_d, Path(output_dir) / "svd_recon_disease_ids.pt")
    torch.save(recon_features, Path(output_dir) / "svd_recon_edge_features.pt")
    save_csv(recon_rows, Path(output_dir) / "svd_reconstructed_edges.csv", ["tsrna_id", "disease_id", "reconstructed_score"])

    return {
        "tsrna_svd_features": tsrna_features,
        "disease_svd_features": disease_features,
        "recon_edge_tsrna": recon_t,
        "recon_edge_disease": recon_d,
        "recon_edge_features": recon_features,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build fold-local SVD features from train positives.")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--num_tsrna", type=int, required=True)
    parser.add_argument("--num_disease", type=int, required=True)
    parser.add_argument("--train_pos_pairs", required=True)
    parser.add_argument("--svd_dim", type=int, default=64)
    parser.add_argument("--svd_topk", type=int, default=20)
    parser.add_argument("--edge_feat_dim", type=int, default=6)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    pairs = torch.load(args.train_pos_pairs, map_location="cpu")
    save_svd_outputs(args.output_dir, args.num_tsrna, args.num_disease, pairs, args.svd_dim, args.svd_topk, args.edge_feat_dim)
    print(f"[build_svd_features] outputs written to: {args.output_dir}")


if __name__ == "__main__":
    main()
