from src.models.ego_clgnn import EgoCLGNN
